import 'dart:convert';
import 'package:http/http.dart' as http;
import '/Global.dart';
import '/UTILITIES/secure_storage_contents.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ProcessUpdateService {
  final UserOrgData _userOrgData = UserOrgData();
  final FlutterSecureStorage _storage = FlutterSecureStorage();

  // Method to update process
  Future<bool> updateProcess(Map<String, dynamic> updatedData) async {
    // Get userId and token from secure storage
    int? userId = await _userOrgData.getUserId();
    final String? token = await _userOrgData.getJwtToken();
    final projectId = await _storage.read(key: 'projectIdentiForUrl');
    
    // Construct the URL dynamically
    final url = Uri.parse(
        Global.getFullUrl('bot-schedule/update-schedule/project/$projectId'));
    
    // Set headers with authorization token
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      // Send the PUT request with updated data
      final response = await http.put(
        url,
        headers: headers,
        body: jsonEncode(updatedData),
      );

      // Print for debugging
      print('Response Body: ${response.body}');
      print('Request Data: $updatedData');
      print('Request URL: $url');
      print('Authorization Token: $token');

      if (response.statusCode == 200) {
        // Return true if the update is successful
        print('Process updated successfully');
        return true;
      } else {
        // Log failure details
        print('Failed to update process. Status Code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      // Log any exceptions
      print('Error occurred while updating process: $e');
      return false;
    }
  }
}

// Example usage
void main() async {
  final processData = {
    "userId": 1,
    "processId": 9,
    "startTime": ["13:32"],
    "repeatOption": "DAILY",
    "active": true,
  };

  final service = ProcessUpdateService();
  final success = await service.updateProcess(processData);
  print('Update Success: $success');
}
