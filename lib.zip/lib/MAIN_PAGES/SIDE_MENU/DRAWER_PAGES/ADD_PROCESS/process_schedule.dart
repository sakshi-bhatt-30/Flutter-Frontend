import 'package:flutter/material.dart';

class EditPage extends StatefulWidget {
  @override
  _EditPageState createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  // Text controllers to manage the text fields in the dialog
  final TextEditingController field1Controller = TextEditingController();
  final TextEditingController field2Controller = TextEditingController();
  final TextEditingController field3Controller = TextEditingController();
  final TextEditingController field4Controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Show the dialog as soon as the page is loaded
    Future.delayed(Duration.zero, () {
      _showEditDialog();
    });
  }

  // Function to show the dialog
  void _showEditDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Information'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: field1Controller,
              decoration: InputDecoration(labelText: 'Field 1'),
            ),
            TextField(
              controller: field2Controller,
              decoration: InputDecoration(labelText: 'Field 2'),
            ),
            TextField(
              controller: field3Controller,
              decoration: InputDecoration(labelText: 'Field 3'),
            ),
            TextField(
              controller: field4Controller,
              decoration: InputDecoration(labelText: 'Field 4'),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              // Handle edit action here (e.g., save data)
              print('Edited Data:');
              print('Field 1: ${field1Controller.text}');
              print('Field 2: ${field2Controller.text}');
              print('Field 3: ${field3Controller.text}');
              print('Field 4: ${field4Controller.text}');

              Navigator.of(context).pop(); // Close the dialog
              Navigator.of(context).pop(); // Go back to the previous page
            },
            child: Text('Edit'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(); // Just return an empty container as the dialog is shown immediately
  }
}
