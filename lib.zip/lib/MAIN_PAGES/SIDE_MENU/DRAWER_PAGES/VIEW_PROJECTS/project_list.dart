import 'dart:async'; // Import this for Timer
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:logging/logging.dart';
import '../../../../MODALS/show_project_modal.dart';
import '../../../../SERVICES/GET SERVICES/show_project_service.dart';
import '../../../../UTILITIES/secure_storage_contents.dart';
import 'add_new_project.dart';
import 'project_details.dart';

class AddProjectPage extends StatefulWidget {
  @override
  _AddProjectPageState createState() => _AddProjectPageState();
}

class _AddProjectPageState extends State<AddProjectPage> {
  final Logger _logger = Logger('UserService');
  final Color customTeal = Color(0xFF61A3FA);
  final _storage = FlutterSecureStorage();
  List<Organization> organizations = [];
  bool isLoading = true;
  bool isAdmin = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadOrganizations();
    _checkAdminStatus();
    // _startAutoRefresh();
  }

  // Method to load organizations
  // Method to load organizations
  Future<void> _loadOrganizations() async {
    if (!mounted) return; // Prevent further execution if widget is not mounted
    setState(() {
      isLoading = true;
    });
    try {
      final service = OrganizationService();
      final List<Organization> fetchedOrganizations =
          await service.fetchOrganizations();
      _logger.info('Fetched Organizations: $fetchedOrganizations');
      if (mounted) {
        setState(() {
          organizations = fetchedOrganizations;
          isLoading = false;
        });
      }
    } catch (e) {
      _logger.info('Error loading organizations: $e');
      if (mounted) {
        setState(() {
          organizations = [];
          isLoading = false;
        });
      }
    }
  }

// Start a periodic timer to refresh the data every 5 seconds
  // void _startAutoRefresh() {
  //   _timer = Timer.periodic(Duration(seconds: 0), (timer) {
  //     if (mounted) {
  //       _loadOrganizations(); // Refresh the organizations list
  //     } else {
  //       timer.cancel(); // Cancel the timer if the widget is not mounted
  //     }
  //   });
  // }

  // Method to check if the user is an admin
  Future<void> _checkAdminStatus() async {
    final userOrgData = UserOrgData();
    String? adminStatus = await userOrgData.getAdminStatus();
    setState(() {
      isAdmin = adminStatus == 'true';
    });
  }

  // Start a periodic timer to refresh the data every 5 seconds
  // void _startAutoRefresh() {
  //   _timer = Timer.periodic(Duration(seconds: 5), (timer) {
  //     _loadOrganizations(); // Refresh the organizations list
  //   });
  // }

  // Cancel the timer when the page is disposed to avoid memory leaks
  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // Method to save the projectIdentiForUrl to secure storage
  Future<void> _saveProjectIdentiForUrl(String projectIdentiForUrl) async {
    try {
      await _storage.write(
          key: 'projectIdentiForUrl', value: projectIdentiForUrl);
      _logger.info('Project Identifer saved successfully.');
    } catch (e) {
      _logger.info('Error saving project identifier: $e');
    }
  }

  // Refresh callback for the RefreshIndicator
  Future<void> _onRefresh() async {
    await _loadOrganizations(); // Trigger the organization refresh
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'All Projects',
          style: TextStyle(color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        actions: [
          // IconButton(
          //   icon: const Icon(Icons.refresh),
          //   onPressed: _onRefresh, // Trigger the refresh action
          // ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _onRefresh, // Pass the refresh logic to the RefreshIndicator
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : organizations.isEmpty
                ? const Center(child: Text('No projects found.'))
                : ListView.builder(
                    itemCount: organizations.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () async {
                          await _saveProjectIdentiForUrl(
                              organizations[index].projectId.toString());

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProjectDetailsPage(),
                            ),
                          );
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5F8FF),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.folder_copy_outlined,
                                  color: Colors.black),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Text(
                                  organizations[index].projectName ??
                                      'unnamed project',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.teal.shade900,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
      ),
      floatingActionButton: isAdmin
          ? FloatingActionButton(
              onPressed: () async {
                // Pass a callback to refresh the organizations list when a new project is added
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AddNewProjectPage(
                      onProjectAdded:
                          _loadOrganizations, // Pass the callback here
                    ),
                  ),
                );
              },
              backgroundColor: Colors.black54,
              shape: const CircleBorder(),
              child: const Icon(
                Icons.add,
                color: Colors.white,
              ),
            )
          : null,
    );
  }
}
