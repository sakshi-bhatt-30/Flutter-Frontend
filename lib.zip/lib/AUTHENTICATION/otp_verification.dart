import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import '../../SERVICES/POST SERVICES/otp_verification_service.dart';
import '../MAIN_PAGES/ONBOARDING/SIGNUP_PAGE/admin_signup.dart'; // Ensure correct path

class OTPVerification extends StatefulWidget {
  final String email; // Only email is passed

  const OTPVerification({Key? key, required this.email}) : super(key: key);

  @override
  _OTPVerificationState createState() => _OTPVerificationState();
}

class _OTPVerificationState extends State<OTPVerification> {
  final TextEditingController _otpController = TextEditingController();
  String? _otpError;

  // Function to handle OTP verification
  Future<void> _verifyOTP() async {
    final otp = _otpController.text;
    final email = widget.email;

    if (otp.isEmpty) {
      setState(() {
        _otpError = 'OTP is required.';
      });
      return;
    }

    if (otp.length != 6) {
      setState(() {
        _otpError = 'OTP must be 6 digits long.';
      });
      return;
    }

    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Email is required for OTP verification.')),
      );
      return;
    }

    setState(() {
      _otpError = null; // Clear error if OTP is valid
    });

    try {
      final registrationService = otpService();
      final statusCode = await registrationService.verifyOtp(
        email: email,
        otp: otp,
      );

      // Handle the response status code
      if (statusCode == 200 || statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('OTP Verified Successfully!')),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => new AdminSignUpPage(email: email)),
        );
      } else {
        // Handle other status codes if needed
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('OTP verification failed')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Page content
          Positioned(
            left: 30,
            top: 215,
            child: Text(
              'Enter OTP',
              style: const TextStyle(
                color: Colors.black,
                fontSize: 36,
                fontFamily: 'Montserrat',
                fontWeight: FontWeight.w700,
              ),
            ),
          ),

          // OTP Input Section
          Positioned(
            left: 30,
            top: 300,
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Enter the 6-digit OTP sent on your mail ID",
                    style: TextStyle(
                      color: Color(0xFF676767),
                      fontSize: 16,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: 315,
                    child: Pinput(
                      controller: _otpController,
                      length: 6,
                      defaultPinTheme: PinTheme(
                        width: 50,
                        height: 50,
                        textStyle: const TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: BoxDecoration(
                          border:
                              Border.all(color: Colors.black.withOpacity(0.3)),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      focusedPinTheme: PinTheme(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xFF61A3FA)),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      submittedPinTheme: PinTheme(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          border:
                              Border.all(color: Colors.black.withOpacity(0.3)),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  if (_otpError != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        _otpError!,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),

          // Submit Button
          Positioned(
            left: 29,
            top: 488,
            child: GestureDetector(
              onTap: _verifyOTP, // Call the function when tapped
              child: Container(
                width: 317,
                height: 55,
                decoration: BoxDecoration(
                  color: const Color(0xFF61A3FA),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Center(
                  child: Text(
                    'Submit',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
